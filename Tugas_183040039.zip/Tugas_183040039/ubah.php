<?php
require 'function.php';

$id = $_GET["id"];
$B = query("SELECT * FROM elektronik4 WHERE id = $id")[0];

if( isset($_POST['submit'])){
    if(tambah($_POST) > 0 ){
        print "<script>
            alert('data berhasil diubah');
            document.location.href = 'index3.php';
            </script>";
    }else{
        print "<script>
            alert('data gagal diubah');
            document.location.href = 'index3.php';
            </script>";
    }
}
?>

<html>
    <head>
        <title>Tambah Data Barang Elektronik</title>
    </head>
    <body>
        <h1>FORM ubah Data Elektronik</h1>
        <form action="" method="post">
            <input type="hidden" name="id" value="<?=$B["id"];?>">

            <label for="Barang"> Barang : </label><br>
            <input type="text" name="Barang" id="Barang" value="<?=$B['Barang'];?>" required><br>

            <label for="Unit">Unit : </label><br>
            <input type="text" name="Unit" id="Unit" value="<?=$B['Unit'];?>" required><br>

            <label for="Harga">Harga : </label><br>
            <input type="textarea" name="Harga" id="Harga" value="<?=$B['Harga'];?>" required><br>

            <label for="Penjualan">Penjualan : </label><br>
            <input type="text" name="Penjualan" id="Penjualan" value="<?=$B['Penjualan'];?>" required><br>

            <label for="Foto">Foto : </label><br>
            <input type="text" name="Foto" id="Foto" value="<?=$B['Foto'];?>" required><br>
            <br>
            <button type="submit" name="submit">Ubah</button>
        </form>
    </body>
</html>